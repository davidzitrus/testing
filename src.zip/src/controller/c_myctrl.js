﻿var app = angular.module('ionic2app', []);
  app.controller('myctrl', function ($scope) {
    $scope.vorname = "David";
    $scope.nachname = "Miz";
  });