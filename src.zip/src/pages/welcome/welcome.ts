﻿import { Component } from '@angular/core';

import { NavController } from 'ionic-angular';
import { TabsPage } from '../tabs/tabs';
import { FriendsPage } from '../friends/friends';
import { Http } from '@angular/http';
import 'rxjs/add/operator/map';
import { AddTechnologyPage } from '../../pages/add-technology/add-technology';

@Component({
    selector: 'page-welcome',
    templateUrl: 'welcome.html'
})
export class WelcomePage {
    public items: any = [];
    constructor(public navCtrl: NavController, public http: Http) {
      
    }

    forward() {
        this.navCtrl.push(TabsPage);
    }
    ionViewWillEnter() {
        this.load();
    }

    // Retrieve the JSON encoded data from the remote server
    // Using Angular 2's Http class and an Observable - then
    // assign this to the items array for rendering to the HTML template
    load() {
        this.http.get('http://www.your-remote-url.suffix/retrieve-data.php')
            .map(res => res.json())
            .subscribe(data => {
                this.items = data;
            });
    }


    // Allow navigation to the AddTechnologyPage for creating a new entry
    addEntry() {
        this.navCtrl.push(TabsPage);
    }


    // Allow navigation to the AddTechnologyPage for amending an existing entry
    // (We supply the actual record to be amended, as this method's parameter,
    // to the AddTechnologyPage
    viewEntry(param) {
        this.navCtrl.push(TabsPage, param);
    }
}


//Now we need to add the necessary UI components to the favourite- web - technologies
//    / src / pages / home / home.html file: